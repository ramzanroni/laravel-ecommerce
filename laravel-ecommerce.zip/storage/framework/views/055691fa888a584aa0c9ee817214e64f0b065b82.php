<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <div class="col-lg-3 p-2 m-4 btn btn-danger">
                <p class="h2 text-white">Total Orders</p>
                <p class="h4"><?php echo e($orders); ?></p>
            </div>
            <div class="col-lg-3 p-2 m-4 btn btn-info">
                <p class="h2 text-white">Total Sales</p>
                <p class="h4"><?php echo e($total); ?></p>
            </div>
            <div class="col-lg-3 p-2 m-4 btn btn-success">
                <p class="h2 ">Total Customer</p>
                <p class="h4"><?php echo e($users); ?></p>
            </div>
            
        </div>
        <div class="col-lg-12 grid-margin">
           <p class="h1 bg-warning text-center">Order Status</p>
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Orders</h4>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>
                                       Order ID
                                    </th>
                                    <th>
                                       Time
                                    </th>
                                    <th>
                                        Status
                                    </th>
                                    <th>
                                        Amount
                                    </th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td class="font-weight-medium">
                                        <?php echo e($s->id); ?>

                                    </td>
                                    <td class="font-weight-medium">
                                        <?php echo e($s->created_at); ?>

                                    </td>
                                    <?php if($s->order_status=='Delivered'): ?>
                                    <td class="font-weight-medium btn btn-success">
                                        <?php echo e($s->order_status); ?>

                                    </td>
                                    <?php endif; ?>
                                   
                                    <?php if($s->order_status=='On Process'): ?>
                                    <td class="font-weight-medium btn btn-warning">
                                        <?php echo e($s->order_status); ?>

                                    </td>
                                    <?php endif; ?>
                                    <?php if($s->order_status=='Cancel'): ?>
                                    <td class="font-weight-medium btn btn-danger">
                                        <?php echo e($s->order_status); ?>

                                    </td>
                                    <?php endif; ?>
                                    <?php if($s->order_status=='Placed'): ?>
                                    <td class="font-weight-medium btn btn-info">
                                        <?php echo e($s->order_status); ?>

                                    </td>
                                    <?php endif; ?>
                                    
                                    
                                    <td class="font-weight-medium">
                                        <?php echo e($s->price); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<script>
    Promise.all([
  loadData(
    "https://s3.eu-central-1.amazonaws.com/fusion.store/ft/data/plotting-multiple-series-on-time-axis-data.json"
  ),
  loadData(
    "https://s3.eu-central-1.amazonaws.com/fusion.store/ft/schema/plotting-multiple-series-on-time-axis-schema.json"
  )
]).then(function(res) {
  const data = res[0];
  const schema = res[1];

  const dataStore = new FusionCharts.DataStore();
  const dataSource = {
    chart: {},
    caption: {
      text: "Sales Analysis"
    },
    subcaption: {
      text: "Grocery & Footwear"
    },
    series: "Type",
    yaxis: [
      {
        plot: "Sales Value",
        title: "Sale Value",
        format: {
          prefix: "$"
        }
      }
    ]
  };
  dataSource.data = dataStore.createDataTable(data, schema);

  new FusionCharts({
    type: "timeseries",
    renderAt: "chart-container",
    width: "100%",
    height: "500",
    dataSource: dataSource
  }).render();
});
</script>
<?php echo $__env->make('admin_panel.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>