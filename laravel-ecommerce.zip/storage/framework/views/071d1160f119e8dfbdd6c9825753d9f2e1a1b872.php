<?php $__env->startSection('content'); ?>
<!-- SECTION -->
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <div class="col-md-12">
                <table class="table">
                    <thead>
                        <th>Order Id</th>
                        <th>Image </th>
                        <th>Name</th>
                        <th>Quanity</th>
                        <th>Color</th>
                        <th>Status</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($c[0]==$s->id): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(session('user')->id == $s->user_id): ?>
                                <?php if($c[1]==$p->id): ?>
                                <tr>
                                <td><?php echo e($s->id); ?></td>
                                <td><img src="uploads/products/<?php echo e($p->id); ?>/<?php echo e($p->image_name); ?>" height="50px" width="50px"></td>
                                <td><?php echo e($p->name); ?></td>
                                <td><?php echo e($c[2]); ?></td>
                                <td><div style="height:25px;width:25px;margin:5px;display:inline-block;background-color: <?php echo e($c[3]); ?>"></div></td>      
                                <td><?php echo e($s->order_status); ?></td>
                                </tr>
                           
                                <?php break; ?>
                                <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                </table>
            </div>
        </div>
        <!-- /Billing Details -->
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('store.storeLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>