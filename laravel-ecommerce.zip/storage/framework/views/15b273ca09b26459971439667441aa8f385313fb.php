 <?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Categories Table</h4>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        Id
                                    </th>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Adress
                                    </th>
                                    <th>
                                        Product Name
                                    </th>
                                    <th>
                                        Quantity
                                    </th>
                                    <th>
                                        Color
                                    </th>
                                    <th>
                                        Placed at
                                    </th>
                                    <th>
                                        Status
                                    </th>

                                    <th>
                                        Update
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($c[0]==$s->id): ?>
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($p): ?>
                                        <?php if( $c[1]==$p->id): ?>
                                <tr>
                                <td><?php echo e($s->id); ?></td>
                                    
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($u->id == $s->user_id): ?>
                                            <td><?php echo e($u->full_name); ?></td>
                                            <td><?php echo e($u->area); ?>, <?php echo e($u->city); ?>, <?php echo e($u->zip); ?> ,Bangladesh</td>
                                            
                                            <?php break; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                   
                                    <td>
                                       
                                        <?php echo e($p->name); ?>

                                       
                                    </td>
                                   <td>
                                        <?php echo e($c[2]); ?>

                                    </td>
                                    <td>
                                        <div style="height:25px;width:25px;margin:5px;display:inline-block;background-color: <?php echo e($c[3]); ?>"></div>
                                    </td>
                                    
                                    <td>
                                        <?php echo e($s->created_at); ?>

                                    </td>
                                    <td>
                                    <?php echo e($s->order_status); ?>

                                    </td>
                                    <td>
                                        <form method="post" style="display:inline-block">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" value="<?php echo e($s->id); ?>" name="orderId">
                                            <select name="stat">
                                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($s->order_status!=$x): ?>
                                                <option value="<?php echo e($x); ?>"><?php echo e($x); ?></option>

                                                <?php endif; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <input type="submit" class="btn btn-sm btn-warning" value="Update">
                                        </form>
                                    </td>
                                    <?php break; ?>
                                    <?php endif; ?>

                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_panel.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>