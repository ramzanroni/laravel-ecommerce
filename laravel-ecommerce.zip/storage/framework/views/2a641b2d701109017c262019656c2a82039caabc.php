<?php $__env->startSection('content'); ?>
   <div class="container">
    <div class="col-md-7 d-flex justify-content-center">
        <?php $__currentLoopData = $userinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form method="POST" action="<?php echo e(route('updatedata', $item->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label>User Name</label>
            <input type="text" name="name" value="<?php echo e($item->full_name); ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" value="<?php echo e($item->email); ?>" class="form-control">
        </div>
        <div class="form-group">
            <label>Phone Number</label>
            <input type="number" name="phone" value="<?php echo e($item->phone); ?>" class="form-control">
        </div>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $add; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group">
        <label>Address</label>
        <input type="text" name="address" value="<?php echo e($data->area); ?>" class="form-control">
    </div>
    <div class="form-group">
        <label>City</label>
        <input type="text" name="city" value="<?php echo e($data->city); ?>" class="form-control">
    </div>
    <div class="form-group">
        <label>ZIP Code</label>
        <input type="text" name="zip" value="<?php echo e($data->zip); ?>" class="form-control">
    </div>
    <button type="submit" class="btn btn-success">Submit</button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form> 
    </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.storeLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>