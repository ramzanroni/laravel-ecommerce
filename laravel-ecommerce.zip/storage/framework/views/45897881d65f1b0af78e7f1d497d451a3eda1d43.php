 <?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">Products Table <a class="btn btn-lg btn-success" style="float:right;color:white" href="<?php echo e(route('admin.products.create')); ?>">+ Add Product</a></h4>
                    <br><br>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        Images
                                    </th>
                                    <th>
                                        Name
                                    </th>
                                    <th>
                                        Delete
                                    </th>
                                    <th>
                                        Price
                                    </th>
                                    <th>
                                        Description
                                    </th>
                                    <th>
                                        Category
                                    </th>
                                    
                                    <th>
                                        Update
                                    </th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $prdlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <img src="../uploads/products/<?php echo e($prd->id); ?>/<?php echo e($prd->image_name); ?>" style="width:100px;height:100px;border-radius:10%;" alt="">
                                    </td>
                                    <td>
                                       <a href="<?php echo e(route('admin.products.edit', ['id' => $prd->id])); ?>" class="btn btn-warning"><?php echo e($prd->name); ?></a>
                                    </td>
                                    <td><a href="<?php echo e(route('admin.products.delete', ['id' => $prd->id])); ?>"class="btn btn-danger">Delete</a></td>
                                    <td>
                                        <?php echo e($prd->price); ?>

                                    </td>
                                    <td>
                                        <?php echo e($prd->description); ?>

                                    </td>
                                    <td>
                                        <?php echo e($prd->category->name); ?>

                                    </td>
                                    
                                    <td><a href="<?php echo e(route('admin.products.edit', ['id' => $prd->id])); ?>" class="btn btn-warning">Edit</a> </td>
                                     
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_panel.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>