<?php $__env->startSection('content'); ?>
<div class="section">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">

            <!-- STORE -->
            <div id="store" class="col-md-12">
                <!-- store products -->
                <div class="row">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- product -->
                    <div class="col-md-4 col-xs-6">
                        <div class="product">
                            <div class="product-img">
                                <img src="uploads/products/<?php echo e($product->id); ?>/<?php echo e($product->image_name); ?>" alt="">
                                <div class="product-label">
                                    <span class="sale">offer</span>
                                    <span class="new"><?php echo e($product->tag); ?></span>
                                </div>
                            </div>
                            <div class="product-body">
                                <h3 class="product-name"><a href="product/<?php echo e($product->id); ?>"><?php echo e($product->name); ?></a></h3>
                                <h4 class="product-price">TK <?php echo e($product->discount); ?> <del class="product-old-price">TK <?php echo e($product->price); ?></del></h4>
                                <div class="product-rating">
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                    <i class="fa fa-star"></i>
                                </div>
                                
                            </div>
                            <div class="add-to-cart">
                                <a class="add-to-cart-btn" href="<?php echo e(route('user.view',['id'=>$product->id])); ?>"><i class="fa fa-shopping-cart"></i>Purchase</a>
                            </div>
                        </div>
                    </div>
                    <!-- /product -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- /STORE -->
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('store.storeLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>