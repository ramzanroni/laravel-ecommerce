<?php $__env->startSection('content'); ?>

<section>
    <div class="container">
        <div class="col-md-12">
            <?php $__currentLoopData = $userinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-5">
                    <img src="<?php echo e(asset('images/faces/face1.jpg')); ?>">
                </div>
                <div class="col-md-7">
                    <p>Username:</p>
                    <p class="bg-info p-2"><?php echo e($item->full_name); ?></p>
                    <p>Email Address</p>
                    <p class="bg-info p-2"><?php echo e($item->email); ?></p>
                    <p>Phone Number</p>
                    <p class="bg-info p-2"><?php echo e($item->phone); ?></p>
                   
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php $__currentLoopData = $add; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <p>Address</p>
           <p class="bg-info p-2"><?php echo e($address->area); ?></p>
           <p>City</p>
           <p class="bg-info p-2"><?php echo e($address->city); ?></p>
        <p>Zipcode</p>
        <p class="bg-info p-2"><?php echo e($address->zip); ?></p>
           <a href="<?php echo e(route('update', $item->id)); ?>" class="btn btn-primary p-3 mt-5">Update Profile</a>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('store.storeLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>